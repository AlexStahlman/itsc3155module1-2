sentence = ''
for i in range(5):
    grab = input('Enter a word: ')
    sentence += grab +' '
print(sentence)
