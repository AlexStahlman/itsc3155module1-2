shoo = int(input('Put in an integer greater than 1'))
print('The square of '+shoo+ ' is '+shoo*shoo)
