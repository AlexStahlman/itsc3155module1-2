compare = input('Type something to compare')
compare_to = input('Type something to compare to')
if compare in compare_to:
    print('true')
else:
    print('false')